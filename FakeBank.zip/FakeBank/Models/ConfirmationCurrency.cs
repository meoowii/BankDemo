﻿namespace FakeBank.Models
{
    public enum ConfirmationCurrency
    {
        PLN = 0,
        EUR = 1,
        USD = 2
    }
}
