﻿namespace FakeBank.Models
{
    public enum TransactionStatus
    {
        Pending = 0, // Oczekujące
        Booked = 1, // Zaksięgowany
        Rejected = 2 // Odrzucony
    }
}
